--------------------------------------------------------BIG DATA - TEMĂ PROIECT: Platformă de învățare online------------------------------------------------------------



---Descriere: Un sistem de gestionare a cursurilor online, înscrierilor studenților, evaluărilor și progresului.
---Diagrama BD: Tabele pentru Cursuri, Studenți, Instructori, Evaluări, Lecții, Înscrieri și Progres.
---Cazuri speciale: Retrageri de la cursuri, evaluări refăcute, cursuri expirate.
---Denormalizare: Include tabele de rezumate pentru statistici rapide, cum ar fi numărul de înscrieri/curs și progresul general al cursanților.
---Temporalitate: Salvează istoricul evaluărilor și modificărilor de cursuri pentru a permite recalculări și raportări în timp.



Tabelele principale:

1.Cursuri
2.Lectii
3.Studenti
4.Instructori
5.Inscrieri
6.Evaluari
7.Progres
8.Certificate
9.Testari
10.Materiale
11.GrupuriDeStudii


Tabele auxiliare:

12.IntrebariQuiz
13.Raspunsuri
14.ScoruriQuiz
15.Comentarii
16.FeedbackInstructori
17.Abonamente
18.Plati
19.ConversatiiGrupuri
20.Forumuri
21.MesajeForum
22.EvenimenteLive //evenimente ce se desfasoara in timp live pe platforma, sesiuni interactive la care studentii pot participa 
23.ParticipariEvenimente //destinat sa inregistram participantii la diferite evenimente ce au loc pe platforma


Tabele pentru administrarea platformei:

24.AdministratoriPlatforma
25.JurnalActivitati
26.SetariPlatforma
