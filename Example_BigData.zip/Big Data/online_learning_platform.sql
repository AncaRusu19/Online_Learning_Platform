-- Tabel pentru cursuri
CREATE TABLE Cursuri (
    curs_id SERIAL PRIMARY KEY,
    nume VARCHAR(255) NOT NULL,
    descriere TEXT,
    categorie VARCHAR(100),
    nivel VARCHAR(50),
    data_creare TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel pentru lecții
CREATE TABLE Lectii (
    lectie_id SERIAL PRIMARY KEY,
    curs_id INT REFERENCES Cursuri(curs_id) ON DELETE CASCADE,
    titlu VARCHAR(255) NOT NULL,
    tip VARCHAR(50), -- tipul poate fi "video", "text", "quiz" etc.
    durata INT, -- durata în minute
    ordine INT, -- ordinea lecției în cadrul cursului
    continut TEXT
);

-- Tabel pentru studenți
CREATE TABLE Studenti (
    student_id SERIAL PRIMARY KEY,
    nume VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    data_inscriere TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    parola VARCHAR(255) NOT NULL
);

-- Tabel pentru instructori
CREATE TABLE Instructori (
    instructor_id SERIAL PRIMARY KEY,
    nume VARCHAR(100) NOT NULL,
    bio TEXT,
    contact VARCHAR(100)
);

-- Tabel pentru înscrieri
CREATE TABLE Inscrieri (
    inscriere_id SERIAL PRIMARY KEY,
    student_id INT REFERENCES Studenti(student_id) ON DELETE CASCADE,
    curs_id INT REFERENCES Cursuri(curs_id) ON DELETE CASCADE,
    data_inscriere TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel pentru evaluări
CREATE TABLE Evaluari (
    evaluare_id SERIAL PRIMARY KEY,
    curs_id INT REFERENCES Cursuri(curs_id) ON DELETE CASCADE,
    student_id INT REFERENCES Studenti(student_id) ON DELETE CASCADE,
    scor INT CHECK(scor >= 0 AND scor <= 100),
    comentarii TEXT
);

-- Tabel pentru progresul studenților
CREATE TABLE Progres (
    progres_id SERIAL PRIMARY KEY,
    student_id INT REFERENCES Studenti(student_id) ON DELETE CASCADE,
    curs_id INT REFERENCES Cursuri(curs_id) ON DELETE CASCADE,
    procent_completat DECIMAL(5,2) CHECK(procent_completat >= 0 AND procent_completat <= 100) DEFAULT 0
);

-- Tabel pentru certificate
CREATE TABLE Certificate (
    certificat_id SERIAL PRIMARY KEY,
    curs_id INT REFERENCES Cursuri(curs_id) ON DELETE CASCADE,
    student_id INT REFERENCES Studenti(student_id) ON DELETE CASCADE,
    data_eliberare TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel pentru testări (quiz-uri)
CREATE TABLE Testari (
    quiz_id SERIAL PRIMARY KEY,
    curs_id INT REFERENCES Cursuri(curs_id) ON DELETE CASCADE,
    titlu VARCHAR(255) NOT NULL,
    scor_maxim INT DEFAULT 100
);

-- Tabel pentru întrebările din quiz-uri
CREATE TABLE IntrebariQuiz (
    intrebare_id SERIAL PRIMARY KEY,
    quiz_id INT REFERENCES Testari(quiz_id) ON DELETE CASCADE,
    intrebare TEXT NOT NULL
);

-- Tabel pentru răspunsuri
CREATE TABLE Raspunsuri (
    raspuns_id SERIAL PRIMARY KEY,
    intrebare_id INT REFERENCES IntrebariQuiz(intrebare_id) ON DELETE CASCADE,
    raspuns TEXT NOT NULL,
    corect BOOLEAN DEFAULT FALSE
);

-- Tabel pentru scorurile obținute la quiz-uri
CREATE TABLE ScoruriQuiz (
    scor_id SERIAL PRIMARY KEY,
    student_id INT REFERENCES Studenti(student_id) ON DELETE CASCADE,
    quiz_id INT REFERENCES Testari(quiz_id) ON DELETE CASCADE,
    scor_obtinut INT
);

-- Tabel pentru materiale
CREATE TABLE Materiale (
    material_id SERIAL PRIMARY KEY,
    curs_id INT REFERENCES Cursuri(curs_id) ON DELETE CASCADE,
    titlu VARCHAR(255) NOT NULL,
    tip VARCHAR(50),
    link TEXT
);

-- Tabel pentru comentarii la lecții
CREATE TABLE Comentarii (
    comentariu_id SERIAL PRIMARY KEY,
    student_id INT REFERENCES Studenti(student_id) ON DELETE CASCADE,
    lectie_id INT REFERENCES Lectii(lectie_id) ON DELETE CASCADE,
    text TEXT NOT NULL,
    data_comentariu TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel pentru feedback la instructori
CREATE TABLE FeedbackInstructori (
    feedback_id SERIAL PRIMARY KEY,
    student_id INT REFERENCES Studenti(student_id) ON DELETE CASCADE,
    instructor_id INT REFERENCES Instructori(instructor_id) ON DELETE CASCADE,
    comentariu TEXT,
    data_feedback TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel pentru abonamente
CREATE TABLE Abonamente (
    abonament_id SERIAL PRIMARY KEY,
    student_id INT REFERENCES Studenti(student_id) ON DELETE CASCADE,
    tip_abonament VARCHAR(50),
    data_expirare TIMESTAMP
);

-- Tabel pentru plăți
CREATE TABLE Plati (
    plata_id SERIAL PRIMARY KEY,
    student_id INT REFERENCES Studenti(student_id) ON DELETE CASCADE,
    suma DECIMAL(10,2) NOT NULL,
    data_plata TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel pentru grupuri de studii
CREATE TABLE GrupuriDeStudii (
    grup_id SERIAL PRIMARY KEY,
    curs_id INT REFERENCES Cursuri(curs_id) ON DELETE CASCADE,
    nume VARCHAR(100)
);

-- Tabel pentru conversațiile din grupurile de studii
CREATE TABLE ConversatiiGrupuri (
    mesaj_id SERIAL PRIMARY KEY,
    grup_id INT REFERENCES GrupuriDeStudii(grup_id) ON DELETE CASCADE,
    student_id INT REFERENCES Studenti(student_id) ON DELETE CASCADE,
    mesaj TEXT NOT NULL,
    data_mesaj TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel pentru forumuri
CREATE TABLE Forumuri (
    forum_id SERIAL PRIMARY KEY,
    curs_id INT REFERENCES Cursuri(curs_id) ON DELETE CASCADE,
    titlu VARCHAR(255) NOT NULL
);

-- Tabel pentru mesaje în forumuri
CREATE TABLE MesajeForum (
    mesaj_id SERIAL PRIMARY KEY,
    forum_id INT REFERENCES Forumuri(forum_id) ON DELETE CASCADE,
    student_id INT REFERENCES Studenti(student_id) ON DELETE CASCADE,
    text TEXT NOT NULL,
    data_mesaj TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel pentru evenimente live
CREATE TABLE EvenimenteLive (
    eveniment_id SERIAL PRIMARY KEY,
    curs_id INT REFERENCES Cursuri(curs_id) ON DELETE CASCADE,
    titlu VARCHAR(255) NOT NULL,
    data_eveniment TIMESTAMP,
    link_eveniment TEXT
);

-- Tabel pentru participarea studenților la evenimente live
CREATE TABLE ParticipariEvenimente (
    participare_id SERIAL PRIMARY KEY,
    student_id INT REFERENCES Studenti(student_id) ON DELETE CASCADE,
    eveniment_id INT REFERENCES EvenimenteLive(eveniment_id) ON DELETE CASCADE
);

-- Tabel pentru administratori
CREATE TABLE AdministratoriPlatforma (
    admin_id SERIAL PRIMARY KEY,
    nume VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    parola VARCHAR(255) NOT NULL,
    permisiuni TEXT
);

-- Tabel pentru jurnalul activităților
CREATE TABLE JurnalActivitati (
    activitate_id SERIAL PRIMARY KEY,
    utilizator_id INT, -- poate face referire la Studenti, Instructori, sau Admini
    actiune TEXT NOT NULL,
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    detalii TEXT
);

-- Tabel pentru setări configurabile ale platformei
CREATE TABLE SetariPlatforma (
    setare_id SERIAL PRIMARY KEY,
    nume VARCHAR(100) UNIQUE NOT NULL,
    valoare TEXT
);
